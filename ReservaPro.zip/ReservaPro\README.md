# ReservaPro

Proyecto organizado con los microservicios del caso de estudio ReservaPro.

Cada microservicio mantiene su propio `pom.xml`, `application.properties` y las capas:

- `controller`
- `Model`
- `repository`
- `service`
- `exception`

## Microservicios

| Microservicio | Puerto | Base de datos | Endpoint principal |
| --- | ---: | --- | --- |
| usuario | 8081 | ms-usuario | `/usuarios` |
| reserva | 8082 | ms-reserva | `/reservas` |
| pago | 8083 | ms-pago | `/pagos` |
| servicio | 8084 | ms-servicio | `/servicios` |
| disponibilidad | 8085 | ms-disponibilidad | `/disponibilidades` |
| cancelacion | 8086 | ms-cancelacion | `/cancelaciones` |
| promocion | 8087 | ms-promocion | `/promociones` |
| notificacion | 8088 | ms-notificacion | `/notificaciones` |
| opinion | 8089 | ms-opinion | `/opiniones` |
| reporte | 8090 | ms-reporte | `/reportes` |
| historial | 8091 | ms-historial | `/historial-reservas` |

## Bases de datos MySQL

Ejecutar en phpMyAdmin antes de levantar los microservicios:

```sql
CREATE DATABASE IF NOT EXISTS `ms-usuario`;
CREATE DATABASE IF NOT EXISTS `ms-reserva`;
CREATE DATABASE IF NOT EXISTS `ms-pago`;
CREATE DATABASE IF NOT EXISTS `ms-servicio`;
CREATE DATABASE IF NOT EXISTS `ms-disponibilidad`;
CREATE DATABASE IF NOT EXISTS `ms-cancelacion`;
CREATE DATABASE IF NOT EXISTS `ms-promocion`;
CREATE DATABASE IF NOT EXISTS `ms-notificacion`;
CREATE DATABASE IF NOT EXISTS `ms-opinion`;
CREATE DATABASE IF NOT EXISTS `ms-reporte`;
CREATE DATABASE IF NOT EXISTS `ms-historial`;
```

Las tablas se crean solas al arrancar cada microservicio porque todos usan:

```properties
spring.jpa.hibernate.ddl-auto=update
```

## URLs para probar

Cada microservicio responde en `/` para confirmar que esta levantado:

```text
GET http://localhost:8081/
GET http://localhost:8082/
GET http://localhost:8083/
GET http://localhost:8084/
GET http://localhost:8085/
GET http://localhost:8086/
GET http://localhost:8087/
GET http://localhost:8088/
GET http://localhost:8089/
GET http://localhost:8090/
GET http://localhost:8091/
```

Para CRUD en Postman usa el endpoint principal de cada microservicio con `GET`, `POST`, `PUT /{id}` y `DELETE /{id}`.

## Flujo sugerido

1. Crear usuario en `POST http://localhost:8081/usuarios`.
2. Crear servicio en `POST http://localhost:8084/servicios`.
3. Crear disponibilidad en `POST http://localhost:8085/disponibilidades`.
4. Crear reserva en `POST http://localhost:8082/reservas`.
5. Crear pago en `POST http://localhost:8083/pagos`.
6. Aprobar pago en `PATCH http://localhost:8083/pagos/{id}/aprobar`.
7. Confirmar reserva en `PATCH http://localhost:8082/reservas/{id}/confirmar`.
8. Registrar historial, opinion, notificacion o cancelacion segun corresponda.
